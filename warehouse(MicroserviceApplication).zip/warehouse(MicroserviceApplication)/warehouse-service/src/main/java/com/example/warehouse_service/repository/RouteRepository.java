package com.example.warehouse_service.repository;

import com.example.warehouse_service.entity.Route;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RouteRepository extends JpaRepository<Route,Long> {
}
