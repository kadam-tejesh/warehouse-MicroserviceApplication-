package com.example.warehouse_service.service;

import com.example.warehouse_service.DTOs.requestDTOs.WarehouseRequestDTO;
import com.example.warehouse_service.DTOs.responseDTOs.InventoryResponseDTO;
import com.example.warehouse_service.DTOs.responseDTOs.WarehouseResponseDTO;
import com.example.warehouse_service.entity.Warehouse;
import com.example.warehouse_service.feign.InventoryInterface;
import com.example.warehouse_service.repository.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class WarehouseService {

    @Autowired
    private WarehouseRepository wareHouseRepository;
    @Autowired
    private InventoryInterface inventoryInterface;
    public ResponseEntity<WarehouseResponseDTO> createWarehouse(WarehouseRequestDTO h){
        try {
            Warehouse w = wareHouseRepository.findByCode(h.getCode());
            WarehouseResponseDTO responseDTO = new WarehouseResponseDTO();
            if (w == null) {
                w = new Warehouse();
                w.setName(h.getName());
                w.setCode(h.getCode());
                w.setLongitude(h.getLongitude());
                w.setLatitude(h.getLatitude());
                w.setCapacity(h.getCapacity());
                w.setStatus(h.getStatus());
                w.setCurrentLoad(h.getCurrentLoad());
                w.setCreatedAt(LocalDateTime.now());
                w.setUpdatedAt(LocalDateTime.now());
                wareHouseRepository.save(w);
                responseDTO.setId(w.getId());
                responseDTO.setName(h.getName());
                responseDTO.setCode(h.getCode());
                responseDTO.setLongitude(h.getLongitude());
                responseDTO.setLatitude(h.getLatitude());
                responseDTO.setCapacity(h.getCapacity());
                responseDTO.setStatus(h.getStatus());
                responseDTO.setCurrentLoad(h.getCurrentLoad());

            } else {
                w.setName(h.getName());
                w.setCode(h.getCode());
                w.setLongitude(h.getLongitude());
                w.setLatitude(h.getLatitude());
                w.setCapacity(h.getCapacity());
                w.setStatus(h.getStatus());
                w.setCurrentLoad(h.getCurrentLoad());
                w.setUpdatedAt(LocalDateTime.now());
                wareHouseRepository.save(w);
                responseDTO.setName(h.getName());
                responseDTO.setCode(h.getCode());
                responseDTO.setLongitude(h.getLongitude());
                responseDTO.setLatitude(h.getLatitude());
                responseDTO.setCapacity(h.getCapacity());
                responseDTO.setStatus(h.getStatus());
                responseDTO.setCurrentLoad(h.getCurrentLoad());

            }
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new WarehouseResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<List<WarehouseResponseDTO>> getWarehouses(){
        try {
            List<Warehouse> warehouseList = wareHouseRepository.findAll();
            List<WarehouseResponseDTO> l = new ArrayList<>();
            for (Warehouse w : warehouseList) {
                WarehouseResponseDTO responseDTO = new WarehouseResponseDTO();
                responseDTO.setId(w.getId());
                responseDTO.setCode(w.getCode());
                responseDTO.setName(w.getName());
                responseDTO.setCapacity(w.getCapacity());
                responseDTO.setLongitude(w.getLongitude());
                responseDTO.setLatitude(w.getLatitude());
                responseDTO.setStatus(w.getStatus());
                responseDTO.setCurrentLoad(w.getCurrentLoad());
                l.add(responseDTO);
            }
            return new ResponseEntity<>(l, HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<WarehouseResponseDTO> getWarehouseById(Long id){
        try {
            Warehouse w = wareHouseRepository.findById(id).orElseThrow(()->new RuntimeException("warehouse not found"));
            WarehouseResponseDTO responseDTO = new WarehouseResponseDTO();
            responseDTO.setId(w.getId());
            responseDTO.setCode(w.getCode());
            responseDTO.setName(w.getName());
            responseDTO.setCapacity(w.getCapacity());
            responseDTO.setLongitude(w.getLongitude());
            responseDTO.setLatitude(w.getLatitude());
            responseDTO.setStatus(w.getStatus());
            responseDTO.setCurrentLoad(w.getCurrentLoad());
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new WarehouseResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<String> deleteWarehouse(Long id){
        try{
            wareHouseRepository.deleteById(id);
            return new ResponseEntity<>("Success",HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>("Failure",HttpStatus.EXPECTATION_FAILED);
    }
    public void updateLoad(Long id,Integer quantity){
        try {
            Warehouse warehouse = wareHouseRepository.findById(id).orElseThrow(() -> new RuntimeException("warehouse not found"));
            warehouse.setCurrentLoad(quantity);
            wareHouseRepository.save(warehouse);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public ResponseEntity<List<InventoryResponseDTO>> inventoryListInWarehouse(Long id){
        try {
            List<InventoryResponseDTO> inventoryList = inventoryInterface.getByWarehouseId(id).getBody();
            return new ResponseEntity<>(inventoryList,HttpStatus.OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
}
