package com.example.warehouse_service.DTOs.responseDTOs;

import lombok.Data;

@Data
public class WarehouseResponseDTO {
    private Long id;
    private String name;
    private String code;
    private Double longitude;
    private Double latitude;
    private Integer capacity;
    private String status;
    private Integer currentLoad;
}
