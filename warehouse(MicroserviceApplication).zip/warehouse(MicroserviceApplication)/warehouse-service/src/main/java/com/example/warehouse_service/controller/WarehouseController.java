package com.example.warehouse_service.controller;

import com.example.warehouse_service.DTOs.requestDTOs.WarehouseRequestDTO;
import com.example.warehouse_service.DTOs.responseDTOs.InventoryResponseDTO;
import com.example.warehouse_service.DTOs.responseDTOs.WarehouseResponseDTO;
import com.example.warehouse_service.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/warehouses")
public class WarehouseController {
    @Autowired
    private WarehouseService wareHouseService;
    @PostMapping(path="/create/warehouse",consumes={"application/json"})
    public ResponseEntity<WarehouseResponseDTO> createWarehouse(@RequestBody WarehouseRequestDTO warehouse){
        return wareHouseService.createWarehouse(warehouse);
    }
    @GetMapping(path="/get/warehouses",produces = {"application/json"})
    public ResponseEntity<List<WarehouseResponseDTO>> getWarehouses(){
        return wareHouseService.getWarehouses();
    }
    @GetMapping(path="/{id}",produces={"application/json"})
    public ResponseEntity<WarehouseResponseDTO> getWarehouseById(@PathVariable Long id){
        return wareHouseService.getWarehouseById(id);
    }
    @DeleteMapping(path="/delete/{id}")
    public ResponseEntity<String> deleteWarehouse(@PathVariable Long id){
        return wareHouseService.deleteWarehouse(id);
    }
    @PutMapping(path="/{id}/increase-load/{quantity}")
    public void updateLoad(@PathVariable Long id,@PathVariable Integer quantity){
         wareHouseService.updateLoad(id,quantity);
    }
    @GetMapping(path="/inventory-list/{id}",produces={"application/json"})
    public ResponseEntity<List<InventoryResponseDTO>> inventoryListInWarehouse(@PathVariable Long id){
        return wareHouseService.inventoryListInWarehouse(id);
    }
}
