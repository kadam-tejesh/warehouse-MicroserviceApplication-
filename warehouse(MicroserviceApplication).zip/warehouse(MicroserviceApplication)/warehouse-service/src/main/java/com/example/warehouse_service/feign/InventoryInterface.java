package com.example.warehouse_service.feign;

import com.example.warehouse_service.DTOs.responseDTOs.InventoryResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient("INVENTORY-SERVICE")
public interface InventoryInterface {
    @GetMapping(path="inventory/get/warehouse{id}",produces ={"application/json"})
    public ResponseEntity<List<InventoryResponseDTO>> getByWarehouseId(@PathVariable Long id);

}
