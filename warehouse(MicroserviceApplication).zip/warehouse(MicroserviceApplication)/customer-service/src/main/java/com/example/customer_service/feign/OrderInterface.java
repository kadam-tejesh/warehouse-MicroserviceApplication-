package com.example.customer_service.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient("ORDER-SERVICE")
public interface OrderInterface {
    @GetMapping("/order/customer/order/{id}")
    public ResponseEntity<List<Long>> getOrderIDsOfCustomer(@PathVariable Long id);
}
