package com.example.product_service.controller;

import com.example.product_service.DTOs.requestDTOs.ProductRequestDTO;
import com.example.product_service.DTOs.responseDTOs.ProductResponseDTO;
import com.example.product_service.entity.Product;
import com.example.product_service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private ProductService productService;
    @PostMapping(path="/create/products",consumes={"application/json"})
    public ResponseEntity<ProductResponseDTO> productRequestDTO(@RequestBody ProductRequestDTO product){
        return productService.createOrUpdateProduct(product);
    }

    @GetMapping(path="/get/products",produces={"application/json"})
    public ResponseEntity<List<ProductResponseDTO>> productResponseDTOS(){
        return productService.getProducts();
    }

    @GetMapping(path="/all/products",produces={"application/json"})
    public ResponseEntity<List<Product>> productList(){
        return productService.getAllProducts();
    }
    @DeleteMapping(path="/delete/products/{id}")
    public ResponseEntity<String> deleteProducts(@PathVariable Long id){
        return productService.deleteProducts(id);
    }
    @GetMapping(path="{id}",produces={"application/json"})
    public ResponseEntity<ProductResponseDTO> getProductById(@PathVariable Long id){
        return productService.getProduct(id);
    }
    @GetMapping(path="/get/products")
    public ResponseEntity<List<Long>> getProductIds(){
        return productService.getProductIds();
    }


}
