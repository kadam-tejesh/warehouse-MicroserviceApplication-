package com.example.inventory_service.DTOs.requestDTOs;

import lombok.Data;

@Data
public class InventoryRequestDTO{
    private Long productId;
    private Long warehouseId;
    private Integer quantity;
}
