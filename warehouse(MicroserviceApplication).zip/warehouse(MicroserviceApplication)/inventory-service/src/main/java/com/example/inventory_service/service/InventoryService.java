package com.example.inventory_service.service;

import com.example.inventory_service.DTOs.requestDTOs.InventoryRequestDTO;
import com.example.inventory_service.DTOs.responseDTOs.InventoryResponseDTO;
import com.example.inventory_service.DTOs.responseDTOs.ProductResponseDTO;
import com.example.inventory_service.DTOs.responseDTOs.WareHouseResponseDTO;
import com.example.inventory_service.entity.Inventory;
import com.example.inventory_service.feign.ProductInterface;
import com.example.inventory_service.feign.WarehouseInterface;
import com.example.inventory_service.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class InventoryService {


    @Autowired
    private InventoryRepository inventoryRepository;
    @Autowired
    private ProductInterface productInterface;
    @Autowired
    private WarehouseInterface warehouseInterface;
    public ResponseEntity<InventoryResponseDTO> addInventory(InventoryRequestDTO inventory) {

        try {

            ProductResponseDTO product =
                    productInterface.getProductById(inventory.getProductId()).getBody();

            WareHouseResponseDTO warehouse =
                    warehouseInterface.getWarehouseById(inventory.getWarehouseId()).getBody();

            if (product == null || warehouse == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            Inventory existingInventory =
                    inventoryRepository.findByProductIdAndWarehouseId(
                            inventory.getProductId(),
                            inventory.getWarehouseId());

            if (existingInventory != null) {

                existingInventory.setQuantity(
                        existingInventory.getQuantity()
                                + inventory.getQuantity());

                existingInventory.setLastUpdated(LocalDateTime.now());

                inventoryRepository.save(existingInventory);

                warehouseInterface.updateLoad(
                        inventory.getWarehouseId(),
                        inventory.getQuantity());

            }

            if (warehouse.getCurrentLoad() + inventory.getQuantity()
                    > warehouse.getCapacity()) {

                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            Inventory inventoryEntity = new Inventory();

            inventoryEntity.setProductId(inventory.getProductId());
            inventoryEntity.setWarehouseId(inventory.getWarehouseId());
            inventoryEntity.setQuantity(inventory.getQuantity());
            inventoryEntity.setReservedQuantity(0);
            inventoryEntity.setLastUpdated(LocalDateTime.now());

            Inventory savedInventory = inventoryRepository.save(inventoryEntity);

            warehouseInterface.updateLoad(
                    inventory.getWarehouseId(),
                    inventory.getQuantity());

            InventoryResponseDTO response = new InventoryResponseDTO();

            response.setId(savedInventory.getId());
            response.setProductId(savedInventory.getProductId());
            response.setProductName(product.getName());
            response.setWarehouseId(savedInventory.getWarehouseId());
            response.setWarehouseName(warehouse.getName());
            response.setQuantity(savedInventory.getQuantity());
            response.setReversedQuantity(savedInventory.getReservedQuantity());
            response.setLastUpdated(savedInventory.getLastUpdated());

            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (Exception e) {

            e.printStackTrace();

            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<InventoryResponseDTO> updateInventory(Long id,Integer quantity){
        try {
            Inventory inventory = inventoryRepository.findById(id).orElseThrow(() -> new RuntimeException("inventory not found"));
            ProductResponseDTO product= productInterface.getProductById(inventory.getProductId()).getBody();
            WareHouseResponseDTO warehouse=warehouseInterface.getWarehouseById(inventory.getWarehouseId()).getBody();
            inventory.setQuantity(inventory.getQuantity() + quantity);
            inventory.setLastUpdated(LocalDateTime.now());
            inventoryRepository.save(inventory);
            warehouseInterface.updateLoad(inventory.getWarehouseId(), inventory.getQuantity());
            InventoryResponseDTO response = new InventoryResponseDTO();
            response.setId(inventory.getId());
            response.setProductId(inventory.getProductId());
            assert product!=null;
            response.setProductName(product.getName());
            response.setWarehouseId(inventory.getWarehouseId());
            assert warehouse!=null;
            response.setWarehouseName(warehouse.getName());
            response.setQuantity(inventory.getQuantity());
            response.setReversedQuantity(inventory.getReservedQuantity());
            response.setLastUpdated(inventory.getLastUpdated());
            return new ResponseEntity<>(response,HttpStatus.OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(new InventoryResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<List<InventoryResponseDTO>> getInventories(){
        try {
            List<Inventory> inventoryList = inventoryRepository.findAll();
            List<InventoryResponseDTO> list = new ArrayList<>();
            for (Inventory i : inventoryList) {
                InventoryResponseDTO response = new InventoryResponseDTO();
                ProductResponseDTO product = productInterface.getProductById(i.getProductId()).getBody();
                WareHouseResponseDTO warehouse=warehouseInterface.getWarehouseById(i.getWarehouseId()).getBody();
                response.setId(i.getId());
                assert product != null;
                response.setProductId(product.getId());
                response.setProductName(product.getName());
                response.setWarehouseId(i.getWarehouseId());
                assert warehouse != null;
                response.setWarehouseName(warehouse.getName());
                response.setQuantity(i.getQuantity());
                response.setReversedQuantity(i.getReservedQuantity());
                response.setLastUpdated(i.getLastUpdated());
                list.add(response);
            }
            return new ResponseEntity<>(list,HttpStatus.OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<List<InventoryResponseDTO>> getByProductId(Long id){
        try {
            ProductResponseDTO product= productInterface.getProductById(id).getBody();
            if(product!=null) {
                List<Inventory> inventoryList = inventoryRepository.findByProductId(id);

                if (inventoryList == null) {
                    throw new RuntimeException("inventory not found");
                }
                List<InventoryResponseDTO> responseDTOS = new ArrayList<>();
                for (Inventory i : inventoryList) {
                    InventoryResponseDTO response = new InventoryResponseDTO();
                    WareHouseResponseDTO warehouse=warehouseInterface.getWarehouseById(i.getWarehouseId()).getBody();
                    response.setId(i.getId());
                    response.setProductId(product.getId());
                    response.setProductName(product.getName());
                    response.setWarehouseId(i.getWarehouseId());
                    assert warehouse!=null;
                    response.setWarehouseName(warehouse.getName());
                    response.setQuantity(i.getQuantity());
                    response.setReversedQuantity(i.getReservedQuantity());
                    response.setLastUpdated(i.getLastUpdated());
                    responseDTOS.add(response);
                }
                return new ResponseEntity<>(responseDTOS, HttpStatus.OK);
            }
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<List<InventoryResponseDTO>> getByWarehouseId(Long id){
        try {
            WareHouseResponseDTO warehouse=warehouseInterface.getWarehouseById(id).getBody();
            if(warehouse!=null) {
                List<Inventory> inventoryList = inventoryRepository.findByWarehouseId(id);
                if (inventoryList == null) {
                    throw new RuntimeException("inventory not found");
                }
                List<InventoryResponseDTO> l = new ArrayList<>();
                for (Inventory i : inventoryList) {
                    InventoryResponseDTO response = new InventoryResponseDTO();
                    ProductResponseDTO product = productInterface.getProductById(i.getProductId()).getBody();
                    response.setId(i.getId());
                    assert product!=null;
                    response.setProductId(product.getId());
                    response.setProductName(product.getName());
                    response.setWarehouseId(i.getWarehouseId());
                    response.setWarehouseName(warehouse.getName());
                    response.setQuantity(i.getQuantity());
                    response.setReversedQuantity(i.getReservedQuantity());
                    response.setLastUpdated(i.getLastUpdated());
                    l.add(response);
                }
                return new ResponseEntity<>(l, HttpStatus.OK);
            }
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<InventoryResponseDTO> getByProductAndWarehouse(Long pid,Long wid){
        try {
            Inventory i = inventoryRepository.findByProductIdAndWarehouseId(pid, wid);
            InventoryResponseDTO response = new InventoryResponseDTO();
            response.setId(i.getId());
            ProductResponseDTO product= productInterface.getProductById(pid).getBody();
            WareHouseResponseDTO warehouse =warehouseInterface.getWarehouseById(wid).getBody();
            assert product !=null;
            response.setProductId(product.getId());
            response.setProductName(product.getName());
            response.setWarehouseId(wid);
            assert warehouse!=null;
            response.setWarehouseName(warehouse.getName());
            response.setQuantity(i.getQuantity());
            response.setReversedQuantity(i.getReservedQuantity());
            response.setLastUpdated(i.getLastUpdated());
            return new ResponseEntity<>(response,HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new InventoryResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<InventoryResponseDTO> deleteInventory(Long id){
        try {
            Inventory i = inventoryRepository.findById(id).orElseThrow(() -> new RuntimeException("Inventory not found"));
            InventoryResponseDTO response = new InventoryResponseDTO();
            if (i != null) {

                response.setId(i.getId());
                ProductResponseDTO product= productInterface.getProductById(i.getProductId()).getBody();
                WareHouseResponseDTO warehouse =warehouseInterface.getWarehouseById(i.getWarehouseId()).getBody();
                assert product !=null;
                response.setProductId(product.getId());
                response.setProductName(product.getName());
                response.setWarehouseId(i.getWarehouseId());
                assert warehouse!=null;
                response.setWarehouseName(warehouse.getName());
                response.setQuantity(i.getQuantity());
                response.setReversedQuantity(i.getReservedQuantity());
                response.setLastUpdated(i.getLastUpdated());
                inventoryRepository.deleteById(id);
            }
            return new ResponseEntity<>(response,HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new InventoryResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<InventoryResponseDTO> getInventory(Long id){
        try {
            Inventory i = inventoryRepository.findById(id).orElseThrow(() -> new RuntimeException("inventory not found"));
            InventoryResponseDTO response = new InventoryResponseDTO();
            ProductResponseDTO product = productInterface.getProductById(i.getProductId()).getBody();
            WareHouseResponseDTO warehouse = warehouseInterface.getWarehouseById(i.getWarehouseId()).getBody();
            response.setId(i.getId());
            assert product != null;
            response.setProductId(product.getId());
            response.setProductName(product.getName());
            response.setWarehouseId(i.getWarehouseId());
            assert warehouse != null;
            response.setWarehouseName(warehouse.getName());
            response.setQuantity(i.getQuantity());
            response.setReversedQuantity(i.getReservedQuantity());
            response.setLastUpdated(i.getLastUpdated());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(new InventoryResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
}
