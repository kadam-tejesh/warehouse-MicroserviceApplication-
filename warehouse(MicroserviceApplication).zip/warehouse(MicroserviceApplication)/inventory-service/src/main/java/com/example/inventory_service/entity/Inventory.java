package com.example.inventory_service.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name="inventory")
@Data
public class Inventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long productId;
    private Long warehouseId;
    private Integer quantity;
    private Integer reservedQuantity=0;
    @Version
    private Integer version;
    private LocalDateTime lastUpdated;


}
