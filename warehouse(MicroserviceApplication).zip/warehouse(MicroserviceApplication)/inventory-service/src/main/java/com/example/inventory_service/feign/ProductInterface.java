package com.example.inventory_service.feign;

import com.example.inventory_service.DTOs.responseDTOs.ProductResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient("PRODUCT-SERVICE")
public interface ProductInterface {
//    @GetMapping(path="/products/get/productIds")
//    public ResponseEntity<List<Long>> getProductIds();
    @GetMapping(path="/products/get/products",produces={"application/json"})
    public ResponseEntity<List<ProductResponseDTO>> productResponseDTOS();
    @GetMapping(path="/products/{id}",produces={"application/json"})
    public ResponseEntity<ProductResponseDTO> getProductById(@PathVariable Long id);
}
