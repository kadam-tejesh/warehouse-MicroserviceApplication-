package com.example.inventory_service.feign;

import com.example.inventory_service.DTOs.responseDTOs.WareHouseResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient(name="WAREHOUSE-SERVICE")
public interface WarehouseInterface {
    @GetMapping(path="/warehouses/{id}")
    public ResponseEntity<WareHouseResponseDTO> getWarehouseById(@PathVariable Long id);
    @PutMapping(path="/warehouses/{id}/increase-load/{quantity}")
    public void updateLoad(@PathVariable Long id, @PathVariable Integer quantity);
}
