package com.example.inventory_service.repository;

import com.example.inventory_service.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface InventoryRepository extends JpaRepository<Inventory,Long> {

    List<Inventory> findByProductId(Long id);
    List<Inventory> findByWarehouseId(Long id);
    Inventory findByProductIdAndWarehouseId(Long productId, Long warehouseId);
    Optional<Inventory> findById(Long id);
    void deleteById(Long id);
}
