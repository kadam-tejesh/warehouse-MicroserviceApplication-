package com.example.auth_service.DTO.ResponseDTO;

import lombok.Data;

@Data
public class UserResponseDTO {
    private String name;
    private String email;
    private String role;
    private Boolean isActive;
}
