package com.example.auth_service.controller;

import com.example.auth_service.DTO.RequestDTO.LoginRequestDTO;
import com.example.auth_service.DTO.RequestDTO.RegisterRequestDTO;
import com.example.auth_service.DTO.ResponseDTO.UserResponseDTO;
import com.example.auth_service.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private AuthService authService;
    @PostMapping(path="/register",consumes={"application/json"},produces={"application/json"})
    public ResponseEntity<UserResponseDTO> userRegistration(@RequestBody RegisterRequestDTO registrationDetails){
        return authService.registerUser(registrationDetails);
    }

    @PostMapping(path ="/login",consumes = {"application/json"})
    public ResponseEntity<String> login(@RequestBody LoginRequestDTO details){
        return authService.generateToken(details);
    }
}
