package com.example.auth_service.service;

import com.example.auth_service.DTO.RequestDTO.LoginRequestDTO;
import com.example.auth_service.DTO.RequestDTO.RegisterRequestDTO;
import com.example.auth_service.DTO.ResponseDTO.UserResponseDTO;
import com.example.auth_service.entity.User;
import com.example.auth_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private JWTService jwtService;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private MyUserServiceDetails myUserServiceDetails;
    public ResponseEntity<UserResponseDTO> registerUser(RegisterRequestDTO registration) {

        try {

            User existingUser =
                    userRepository.findByEmail(registration.getEmail());

            if(existingUser != null) {

                return new ResponseEntity<>(
                        HttpStatus.CONFLICT
                );
            }

            User user = new User();

            user.setUsername(registration.getUsername());
            user.setEmail(registration.getEmail());
            user.setPassword(
                    passwordEncoder.encode(registration.getPassword())
            );
            user.setRole(registration.getRole());

            user.setCreatedAt(LocalDateTime.now());
            user.setUpdatedAt(LocalDateTime.now());
            user.setIsActive(true);

            userRepository.save(user);

            UserResponseDTO responseDTO = new UserResponseDTO();

            responseDTO.setEmail(user.getEmail());
            responseDTO.setRole(user.getRole());
            responseDTO.setIsActive(user.getIsActive());
            responseDTO.setName(user.getUsername());

            return new ResponseEntity<>(
                    responseDTO,
                    HttpStatus.CREATED
            );

        } catch (Exception e) {

            e.printStackTrace();

            return new ResponseEntity<>(
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }
    public ResponseEntity<String> generateToken(LoginRequestDTO login){
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            login.getEmail(),
                            login.getPassword()
                    )
            );

            if(authentication.isAuthenticated()){
                UserDetails userDetails =
                        myUserServiceDetails
                                .loadUserByUsername(login.getEmail());
                return new ResponseEntity<>(jwtService.generateToken(userDetails),HttpStatus.OK);
            }

        } catch (Exception e) {
            e.getStackTrace();
        }

        return new ResponseEntity<>("fail",HttpStatus.BAD_REQUEST);
    }

}
