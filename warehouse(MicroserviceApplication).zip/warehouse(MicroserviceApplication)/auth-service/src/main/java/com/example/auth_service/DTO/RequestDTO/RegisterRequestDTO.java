package com.example.auth_service.DTO.RequestDTO;

import lombok.Data;

@Data
public class RegisterRequestDTO {
    private String username;
    private String email;
    private String password;
    private String role;
}
