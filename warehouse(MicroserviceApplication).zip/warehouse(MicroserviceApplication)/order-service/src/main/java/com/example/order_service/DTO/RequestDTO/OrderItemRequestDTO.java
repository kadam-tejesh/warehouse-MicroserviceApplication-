package com.example.order_service.DTO.RequestDTO;

import lombok.Data;

@Data
public class OrderItemRequestDTO {
    private Long productId;
    private Long quantity;
}
