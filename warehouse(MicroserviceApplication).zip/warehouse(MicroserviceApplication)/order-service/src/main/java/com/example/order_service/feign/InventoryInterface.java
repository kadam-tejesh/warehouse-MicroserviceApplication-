package com.example.order_service.feign;

import com.example.order_service.DTO.ResponseDTO.InventoryResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("INVENTORY-SERVICE")
public interface InventoryInterface {
    @GetMapping(path="/inventory/get/inventory/p{pid}/w{wid}",produces = {"application/json"})
    public ResponseEntity<InventoryResponseDTO> getByProductAndWarehouse(@PathVariable Long pid, @PathVariable Long wid);
    @PatchMapping(path="/inventory/update/{id}/{quantity}")
    public void updateInventory(@PathVariable Long id,@PathVariable Integer quantity);
}
