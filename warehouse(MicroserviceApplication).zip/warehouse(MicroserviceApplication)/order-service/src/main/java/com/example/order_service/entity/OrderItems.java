package com.example.order_service.entity;

import com.example.order_service.DTO.ResponseDTO.ProductResponseDTO;
import com.example.order_service.DTO.ResponseDTO.WarehouseResponseDTO;
import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name="order_items")
@Data
public class OrderItems {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="order_id")
    private Order order;

   private Long productId;

   private Long warehouseId;
    private Long quantity;
    private BigDecimal unitPrice;
    private BigDecimal subTotal;

}
