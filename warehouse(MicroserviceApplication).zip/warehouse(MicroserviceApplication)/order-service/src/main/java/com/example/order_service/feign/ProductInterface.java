package com.example.order_service.feign;

import com.example.order_service.DTO.ResponseDTO.ProductResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("PRODUCT-SERVICE")
public interface ProductInterface {
    @GetMapping(path="{id}",produces={"application/json"})
    public ResponseEntity<ProductResponseDTO> getProductById(@PathVariable Long id);
}
