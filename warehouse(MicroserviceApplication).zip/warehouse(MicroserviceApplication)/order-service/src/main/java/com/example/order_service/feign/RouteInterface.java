package com.example.order_service.feign;

import com.example.order_service.DTO.ResponseDTO.WarehouseResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name="WAREHOUSE-SERVICE",contextId = "routesClient")
public interface RouteInterface {
    @GetMapping(path="/routes/distance/warehouse/{id}")
    public List<WarehouseResponseDTO> getWareHousesSorted(@PathVariable Long id);
}
