package com.example.order_service.DTO.ResponseDTO;

import lombok.Data;

@Data
public class WarehouseResponseDTO {
    private Long id;
    private String name;
    private String code;
    private Double longitude;
    private Double latitude;
    private Integer capacity;
    private String status;
    private Integer currentLoad;
}
