package com.example.order_service.feign;

import com.example.order_service.DTO.ResponseDTO.WarehouseResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="WAREHOUSE-SERVICE",contextId = "warehouseClient")
public interface WarehouseInterface {
    @GetMapping("/warehouse/start/id")
    public ResponseEntity<Long> getStartId();
    @PatchMapping("/warehouse/update-load/{id}/{load}")
    public void updateCurrentLoad(@PathVariable Long id,@PathVariable Integer load);
    @GetMapping(path="/warehouse/{id}",consumes={"application/json"})
    public ResponseEntity<WarehouseResponseDTO> getWarehouseById(@PathVariable Long id);
}
