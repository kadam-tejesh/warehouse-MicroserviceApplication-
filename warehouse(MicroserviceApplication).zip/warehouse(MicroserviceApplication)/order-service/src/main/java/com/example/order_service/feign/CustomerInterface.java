package com.example.order_service.feign;

import com.example.order_service.DTO.ResponseDTO.CustomerResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
@FeignClient("CUSTOMER-SERVICE")
public interface CustomerInterface {
    @GetMapping(path="/{id}",produces={"application/json"})
    public ResponseEntity<CustomerResponseDTO> getCustomerById(@PathVariable Long id);
}
