package com.example.order_service.service;

import com.example.order_service.DTO.RequestDTO.OrderItemRequestDTO;
import com.example.order_service.DTO.RequestDTO.OrderRequestDTO;
import com.example.order_service.DTO.ResponseDTO.*;
import com.example.order_service.entity.Order;
import com.example.order_service.entity.OrderItems;
import com.example.order_service.feign.*;
import com.example.order_service.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class OrderService {

    @Autowired
    private InventoryInterface inventoryInterface;
    @Autowired
    private WarehouseInterface warehouseInterface;
    @Autowired
    private CustomerInterface customerInterface;
    @Autowired
    private RouteInterface routeInterface;
    @Autowired
    private ProductInterface productInterface;
    @Autowired
    private OrderRepository orderRepository;

    public ResponseEntity<OrderResponseDTO> placeOrder(OrderRequestDTO order){
        try {
            CustomerResponseDTO customer = customerInterface.getCustomerById(order.getCustomerId()).getBody();
            if (order.getItems().isEmpty()) {
                throw new RuntimeException("order must contain at least one item to get placed");
            }
            Order order1 = new Order();
            order1.setCustomerId(order.getCustomerId());
            order1.setStatus("CREATED");
            order1.setCreatedAt(LocalDateTime.now());
            order1.setUpdatedAt(LocalDateTime.now());
            List<OrderItems> orderItemsList = new ArrayList<>();
            Long startWarehouseId = warehouseInterface.getStartId().getBody();
            BigDecimal totalAmount = BigDecimal.ZERO;
            List<WarehouseResponseDTO> warehouses = routeInterface.getWareHousesSorted(startWarehouseId);
            for (OrderItemRequestDTO item : order.getItems()) {
                if (item.getQuantity() <= 0) {
                    throw new RuntimeException("items should be at least one");
                }
                ProductResponseDTO product = productInterface.getProductById(item.getProductId()).getBody();
                Long remainingQuantity = item.getQuantity();
                for (WarehouseResponseDTO warehouse : warehouses) {
                    if (remainingQuantity == 0)
                        break;
                    assert product != null;
                    InventoryResponseDTO inventory = inventoryInterface.getByProductAndWarehouse(product.getId(), warehouse.getId()).getBody();
                    if (inventory == null) continue;
                    int available = inventory.getQuantity() - inventory.getReversedQuantity();
                    if (available <= 0) continue;
                    int allocate = (int) Math.min(remainingQuantity, available);
                    System.out.println("Warehouse: " + warehouse.getId() +
                            " Available: " + available +
                            " Remaining: " + remainingQuantity);
                    //saving inventory
                    inventory.setQuantity(inventory.getQuantity() - allocate);
                    inventory.setLastUpdated(LocalDateTime.now());
                    inventoryInterface.updateInventory(inventory.getId(),inventory.getQuantity());
                    // updating the warehouse load
                    Integer load=warehouse.getCurrentLoad() + allocate;
                    warehouse.setCurrentLoad(load);
                    warehouseInterface.updateCurrentLoad(warehouse.getId(),load);
                    // Create order item
                    OrderItems orderItem = new OrderItems();
                    orderItem.setOrder(order1);
                    orderItem.setProductId(product.getId());
                    orderItem.setWarehouseId(warehouse.getId());
                    orderItem.setQuantity((long) allocate);
                    orderItem.setUnitPrice(product.getPrice());
                    BigDecimal subTotal = product.getPrice().multiply(BigDecimal.valueOf(allocate));
                    orderItem.setSubTotal(subTotal);
                    orderItemsList.add(orderItem);
                    totalAmount = totalAmount.add(subTotal);
                    remainingQuantity -= allocate;
                }
                if (remainingQuantity > 0) {
                    throw new RuntimeException("insufficient stock for" + product.getName());
                }
            }
            order1.setOrderNo("ORD-" + System.currentTimeMillis());
            order1.setOrderItemsList(orderItemsList);
            order1.setTotalAmount(totalAmount);
            orderRepository.save(order1);
            return new ResponseEntity<>(orderResponseDTO(order1), HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new OrderResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
    private OrderResponseDTO orderResponseDTO(Order order){
        CustomerResponseDTO customer = customerInterface.getCustomerById(order.getCustomerId()).getBody();
        OrderResponseDTO responseDTO=new OrderResponseDTO();
        assert customer != null;
        responseDTO.setCustomerName(customer.getName());
        responseDTO.setOrderNo(order.getOrderNo());
        responseDTO.setOrderId(order.getId());
        responseDTO.setTotalAmount(order.getTotalAmount());
        responseDTO.setStatus(order.getStatus());
        responseDTO.setCreatedAt(order.getCreatedAt());
        List<OrderItems> orderItemResponseList=order.getOrderItemsList();
        List<OrderItemResponseDTO> orderItemResponseDTOList=new ArrayList<>();
        for(OrderItems items:orderItemResponseList){
            OrderItemResponseDTO itemResponseDTO=new OrderItemResponseDTO();
            ProductResponseDTO product=productInterface.getProductById(items.getProductId()).getBody();
            WarehouseResponseDTO warehouse=warehouseInterface.getWarehouseById(items.getWarehouseId()).getBody();
            itemResponseDTO.setQuantity(items.getQuantity());
            assert product!=null;
            itemResponseDTO.setProductName(product.getName());
            itemResponseDTO.setUnitPrice(items.getUnitPrice());
            itemResponseDTO.setSubTotal(items.getSubTotal());
            itemResponseDTO.setProductId(product.getId());
            assert warehouse!=null;
            itemResponseDTO.setWarehouseId(warehouse.getId());
            itemResponseDTO.setWarehouseName(warehouse.getName());
            orderItemResponseDTOList.add(itemResponseDTO);
        }
        responseDTO.setItems(orderItemResponseDTOList);
        responseDTO.setCustomerId(order.getCustomerId());

        return responseDTO;
    }

    public ResponseEntity<List<OrderResponseDTO>> getOrders(){
        try {
            List<Order> orderList = orderRepository.findAll();
            List<OrderResponseDTO> responseDTOList = new ArrayList<>();
            for (Order o : orderList) {
                OrderResponseDTO response = new OrderResponseDTO();
                List<OrderItems> orderItems = o.getOrderItemsList();
                CustomerResponseDTO customer = customerInterface.getCustomerById(o.getCustomerId()).getBody();
                List<OrderItemResponseDTO> orderItemResponseDTOS = new ArrayList<>();
                for (OrderItems items : orderItems) {
                    OrderItemResponseDTO responseDTO = new OrderItemResponseDTO();
                    ProductResponseDTO product=productInterface.getProductById(items.getProductId()).getBody();
                    WarehouseResponseDTO warehouse=warehouseInterface.getWarehouseById(items.getWarehouseId()).getBody();
                    assert product!=null;
                    assert warehouse !=null;
                    responseDTO.setProductId(product.getId());
                    responseDTO.setQuantity(items.getQuantity());
                    responseDTO.setProductName(product.getName());
                    responseDTO.setUnitPrice(items.getUnitPrice());
                    responseDTO.setSubTotal(items.getSubTotal());
                    responseDTO.setWarehouseId(warehouse.getId());
                    responseDTO.setWarehouseName(warehouse.getName());
                    orderItemResponseDTOS.add(responseDTO);
                }
                response.setOrderId(o.getId());
                response.setOrderNo(o.getOrderNo());
                response.setStatus(o.getStatus());
                response.setItems(orderItemResponseDTOS);
                response.setCreatedAt(o.getCreatedAt());
                assert customer!=null;
                response.setCustomerName(customer.getName());
                response.setTotalAmount(o.getTotalAmount());
                response.setCustomerId(o.getCustomerId());
                responseDTOList.add(response);

            }
            return new ResponseEntity<>(responseDTOList,HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<OrderResponseDTO> getOrderById(Long id){
        try {
            Order o = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("order not found"));
            List<OrderItems> orderItems = o.getOrderItemsList();
            OrderResponseDTO orderResponseDTO = new OrderResponseDTO();
            List<OrderItemResponseDTO> orderItemResponseDTOS = new ArrayList<>();
            for (OrderItems items : orderItems) {
                OrderItemResponseDTO responseDTO = new OrderItemResponseDTO();
                ProductResponseDTO product=productInterface.getProductById(items.getProductId()).getBody();
                WarehouseResponseDTO warehouse=warehouseInterface.getWarehouseById(items.getWarehouseId()).getBody();
                assert product!=null;
                assert warehouse !=null;
                responseDTO.setProductId(product.getId());
                responseDTO.setQuantity(items.getQuantity());
                responseDTO.setProductName(product.getName());
                responseDTO.setUnitPrice(items.getUnitPrice());
                responseDTO.setSubTotal(items.getSubTotal());
                responseDTO.setWarehouseId(warehouse.getId());
                responseDTO.setWarehouseName(warehouse.getName());
                orderItemResponseDTOS.add(responseDTO);
            }
            CustomerResponseDTO customer = customerInterface.getCustomerById(o.getCustomerId()).getBody();
            orderResponseDTO.setCustomerId(o.getCustomerId());
            orderResponseDTO.setOrderNo(o.getOrderNo());
            orderResponseDTO.setStatus(o.getStatus());
            orderResponseDTO.setItems(orderItemResponseDTOS);
            orderResponseDTO.setTotalAmount(o.getTotalAmount());
            orderResponseDTO.setCreatedAt(o.getCreatedAt());
            assert customer!=null;
            orderResponseDTO.setCustomerName(customer.getName());
            orderResponseDTO.setOrderId(o.getId());
            return new ResponseEntity<>(orderResponseDTO,HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new OrderResponseDTO(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<String> updateOrderStatus(Long id, String status){
        try {
            Order o = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("order not found"));
            o.setStatus(status);
            return new ResponseEntity<>("success", HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>("failure",HttpStatus.OK);
    }
    public ResponseEntity<String> deleteOrderById(Long id){
        try{
            orderRepository.deleteById(id);
            return new ResponseEntity<>("success",HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>("failure", HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<List<OrderResponseDTO>> ordersByCustomer(Long id){
        try {
            List<Order> ordersList=orderRepository.findByCustomerId(id);
            List<OrderResponseDTO> orderResponseDTOS = new ArrayList<>();
            for (Order o : ordersList) {
                List<OrderItems> orderItem = o.getOrderItemsList();
                List<OrderItemResponseDTO> orderItemResponseDTOS = new ArrayList<>();
                for (OrderItems items : orderItem) {
                    OrderItemResponseDTO itemResponseDTO = new OrderItemResponseDTO();
                    ProductResponseDTO product=productInterface.getProductById(items.getProductId()).getBody();
                    WarehouseResponseDTO warehouse=warehouseInterface.getWarehouseById(items.getWarehouseId()).getBody();
                    assert product!=null;
                    assert warehouse !=null;
                    itemResponseDTO.setQuantity(items.getQuantity());
                    itemResponseDTO.setProductName(product.getName());
                    itemResponseDTO.setUnitPrice(items.getUnitPrice());
                    itemResponseDTO.setSubTotal(items.getSubTotal());
                    itemResponseDTO.setWarehouseId(warehouse.getId());
                    itemResponseDTO.setWarehouseName(warehouse.getName());
                    itemResponseDTO.setProductId(warehouse.getId());
                    orderItemResponseDTOS.add(itemResponseDTO);
                }
                OrderResponseDTO responseDTO = new OrderResponseDTO();
                CustomerResponseDTO customer = customerInterface.getCustomerById(o.getCustomerId()).getBody();
                responseDTO.setOrderId(o.getId());
                responseDTO.setOrderNo(o.getOrderNo());
                responseDTO.setCustomerId(o.getCustomerId());
                assert customer!=null;
                responseDTO.setCustomerName(customer.getName());
                responseDTO.setTotalAmount(o.getTotalAmount());
                responseDTO.setStatus(o.getStatus());
                responseDTO.setCreatedAt(o.getCreatedAt());
                responseDTO.setItems(orderItemResponseDTOS);
                orderResponseDTOS.add(responseDTO);
            }
            return new ResponseEntity<>(orderResponseDTOS, HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<List<OrderResponseDTO>> getStatus(String status){
        try {
            List<Order> orderList = orderRepository.findByStatus(status);
            List<OrderResponseDTO> orderResponseDTOS = new ArrayList<>();
            for (Order o : orderList) {
                List<OrderItems> orderItem = o.getOrderItemsList();
                List<OrderItemResponseDTO> orderItemResponseDTOS = new ArrayList<>();
                for (OrderItems items : orderItem) {
                    OrderItemResponseDTO itemResponseDTO = new OrderItemResponseDTO();
                    ProductResponseDTO product=productInterface.getProductById(items.getProductId()).getBody();
                    WarehouseResponseDTO warehouse=warehouseInterface.getWarehouseById(items.getWarehouseId()).getBody();
                    assert product!=null;
                    assert warehouse !=null;
                    itemResponseDTO.setQuantity(items.getQuantity());
                    itemResponseDTO.setProductName(product.getName());
                    itemResponseDTO.setUnitPrice(items.getUnitPrice());
                    itemResponseDTO.setSubTotal(items.getSubTotal());
                    itemResponseDTO.setWarehouseId(warehouse.getId());
                    itemResponseDTO.setWarehouseName(warehouse.getName());
                    itemResponseDTO.setProductId(product.getId());
                    orderItemResponseDTOS.add(itemResponseDTO);
                }
                OrderResponseDTO responseDTO = new OrderResponseDTO();
                CustomerResponseDTO customer = customerInterface.getCustomerById(o.getCustomerId()).getBody();
                responseDTO.setOrderId(o.getId());
                responseDTO.setOrderNo(o.getOrderNo());
                responseDTO.setCustomerId(o.getCustomerId());
                assert customer!=null;
                responseDTO.setCustomerName(customer.getName());
                responseDTO.setTotalAmount(o.getTotalAmount());
                responseDTO.setStatus(o.getStatus());
                responseDTO.setCreatedAt(o.getCreatedAt());
                responseDTO.setItems(orderItemResponseDTOS);
                orderResponseDTOS.add(responseDTO);
            }
            return new ResponseEntity<>(orderResponseDTOS, HttpStatus.OK);
        }
        catch(Exception e){
            e.getStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
    public ResponseEntity<List<Long>> getOrderIDsOfCustomer(Long id){
        try {
            List<Order> orderList = orderRepository.findByCustomerId(id);
            List<Long> orderIds = new ArrayList<>();
            for (Order o : orderList) {
                orderIds.add(o.getId());
            }
            return new ResponseEntity<>(orderIds, HttpStatus.OK);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(),HttpStatus.EXPECTATION_FAILED);
    }
}
